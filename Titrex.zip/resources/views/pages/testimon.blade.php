<!-- ======= Testimonials Section ======= -->
<section id="portfolio" class="testimonials">
    <div class="container" data-aos="fade-up">
      <div class="section-title">
        <h2>Portifolio</h2>
      </div>

      <div class="testimonials-slider swiper-container" data-aos="fade-up" data-aos-delay="100">
        <div class="swiper-wrapper">

          <div class="swiper-slide">
            <div class="testimonial-wrap">
              <div class="card" style="width: 18rem;">
                <img class="card-img-top" src="{{ asset('assets/img/kingcity.png') }}" alt="Card image cap">
                <div class="card-body">
                  <a href="https:\\mcb.or.tz" class="get-started-btn">Read more</a>
                </div>
              </div>
            </div>
          </div><!-- End testimonial item -->

          <div class="swiper-slide">
            <div class="testimonial-wrap">
              <div class="card" style="width: 18rem;">
                <img class="card-img-top" src="{{ asset('assets/img/movietrex.png') }}" alt="Card image cap">
                <div class="card-body">
                  <a href="https:\\mcb.or.tz" class="get-started-btn">Read more</a>
                </div>
              </div>
            </div>
          </div><!-- End testimonial item -->

          <div class="swiper-slide">
            <div class="testimonial-wrap">
              <div class="card" style="width: 18rem;">
                <img class="card-img-top" src="{{ asset('assets/img/mcb.png') }}" alt="Card image cap">
                <div class="card-body">
                  <a href="https:\\mcb.or.tz" class="get-started-btn">Read more</a>
                </div>
              </div>
              {{-- <div class="testimonial-item">
                <a href="">
                  <img src="assets/img/mcb.png" class="testimonial-img" alt="">
                </a>
              </div> --}}
            </div>
          </div><!-- End testimonial item -->

          <div class="swiper-slide">
            <div class="testimonial-wrap">
              <div class="card" style="width: 18rem;">
                <img class="card-img-top" src="{{ asset('assets/img/titrex.png') }}" alt="Card image cap">
                <div class="card-body">
                  <a href="https:\\mcb.or.tz" class="get-started-btn">Read more</a>
                </div>
              </div>
            </div>
          </div><!-- End testimonial item -->

        </div>
        <div class="swiper-pagination"></div>
      </div>

    </div>
  </section>
  <!-- End Testimonials Section -->