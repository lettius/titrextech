<!-- ======= About Section ======= -->
<section id="about" class="about section-bg">
    <div class="container" data-aos="fade-up">

      <div class="row no-gutters">
        <div class="content col-xl-6 d-flex align-items-stretch">
          <div class="content">
            <h4>Our company</h4>
            <p class="text-muted">
              Company deal with system development including web design,web development and mobile development,
              <br>Security system such as CCTV System installation and configuration and Data and Voice installation and configuration.
            </p>
          </div>
        </div>
        <div class="col-xl-6 d-flex align-items-stretch">
          <div class="icon-boxes d-flex flex-column justify-content-center">
            <div class="row">
              <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="100" style="">
                <h4>Mission</h4>
                <p class="text-muted">Delivering innovative and reliable solutions to meet our clients needs with utmost quality and perfection throughout development</p>
              </div>
              <div class="col-md-6 icon-box" data-aos="fade-up" data-aos-delay="200">
                <h4>Vision</h4>
                <p class="text-muted">To become an integrated ICT Solution provider in both deliverancy and ethics</p>
              </div>
            </div>
          </div><!-- End .content-->
        </div>
      </div>

    </div>
  </section>
  <!-- End About Section -->