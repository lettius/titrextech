<!-- ======= Clients Section ======= -->
<section id="clients" class="clients">
    <div class="container" data-aos="zoom-in">

      <div class="clients-slider swiper-container">
        <div class="swiper-wrapper align-items-center">
          <div class="swiper-slide"><img src="{{ asset('assets/img/clients/client-9.png') }}" class="img-fluid" alt=""></div>
          <div class="swiper-slide"><img src="{{ asset('assets/img/clients/client-9.png') }}" class="img-fluid" alt=""></div>
          <div class="swiper-slide"><img src="{{ asset('assets/img/clients/client-9.png') }}" class="img-fluid" alt=""></div>
          <div class="swiper-slide"><img src="{{ asset('assets/img/clients/client-9.png') }}" class="img-fluid" alt=""></div>
          <div class="swiper-slide"><img src="{{ asset('assets/img/clients/client-9.png') }}" class="img-fluid" alt=""></div>
          <div class="swiper-slide"><img src="{{ asset('assets/img/clients/client-9.png') }}" class="img-fluid" alt=""></div>
          <div class="swiper-slide"><img src="{{ asset('assets/img/clients/client-9.png') }}" class="img-fluid" alt=""></div>
        </div>
        <div class="swiper-pagination"></div>
      </div>

    </div>
  </section>
  <!-- End Clients Section -->