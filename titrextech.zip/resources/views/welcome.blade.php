@extends('layouts.app')

@section('content')

@include('pages.clients')

@include('pages.about')

@include('pages.count')

{{-- @include('pages.tabs') --}}

@include('pages.services')

{{-- @include('pages.portifolio') --}}

@include('pages.testimon')

@include('pages.team')

@include('pages.contacts')

@endsection